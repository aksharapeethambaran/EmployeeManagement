<?php

namespace App\Http\Controllers;
use Session;
use Illuminate\Http\Request;
use App\Employee;
use DB;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employee = DB::select('select * from employees');
        return view('employee/employeedisplay',compact('employee'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function viewemployeeform()
    {
       return view('employee/employeeform');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function insert(Request $request)
    {
        $employee = new Employee();
        $employee->name = request('name');
        $employee->gender = request('gender');
        $employee->vehicle = request('vehicle');
        $employee->description = request('description');
        $files = $request->file('file');
        $filename=$files->getClientOriginalName();
        
        $destinationPath = 'image/'; // upload path
       
        $profileImage = time().'.'.$filename;
        $files->move($destinationPath, $profileImage);
        $employee->file = $profileImage;
        $employee->save();
        return redirect('/viewemployeeform');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employee = DB::select('select * from employees where id = ?',[$id]);
        return view('employee/employeeupdate',compact('employee'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editsave(Request $request)
    {
       $name = $request->input('name');
         $gender = $request->input('gender');
        $vehicle = $request->input('vehicle');
        $description = $request->input('description');
        $editid = $request->input('editid');
        if($request->file('image')!="") {
           
            
         $image = $request->file('image');
          
        $filename = $image->getClientOriginalName();
             
        $image->move(public_path('/image'), $filename);
        $image = $request->file('image')->getClientOriginalName();
    }else{
            
           $files =$request->input('file');
            
        
        $destinationPath = 'image/'; // upload path
        $profileImage = $files;
        //$files->move($destinationPath, $profileImage);
        $image=$profileImage;
        }
       
        $data = array("name"=>$name,"gender"=>$gender,"vehicle"=>$vehicle,"description"=>$description,"file"=>$image);
        
 
           // Update
           employee::updateData($editid, $data);

           

           Session::flash('message','Update successfully.');
        return redirect()->action('EmployeeController@index',['id'=>0]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $emp = Employee::find($id);
      $image_path = asset("image/{$emp->file}");
     
   unlink("image/".$emp->file);
        //unlink($image_path);
        DB::table('employees')->where('id', '=', $id)->delete();
        
         return redirect()->action('EmployeeController@index',['id'=>0]);
    }
}
