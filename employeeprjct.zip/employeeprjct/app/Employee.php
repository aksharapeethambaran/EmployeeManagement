<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    public static function updateData($id,$data){
    DB::table('employees')
      ->where('id', $id)
      ->update($data);
}
    
}
