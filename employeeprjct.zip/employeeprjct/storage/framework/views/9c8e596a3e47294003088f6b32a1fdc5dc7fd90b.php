<!DOCTPE html>
<html>
<head>
<title>View Student Records</title>
    <h1>Employee Management</h1>
    <h3><a href = '<?php echo e(URL::to('viewemployeeform')); ?>'>Add Employee</a></h3>
</head>
<body>
<table border = "1">
<tr>
<td>Id</td>
<td>Name</td>
<td>Description</td>
<td>Gender</td>
<td>Vehicle</td>
<td>Image</td>
</tr>
<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($user->id); ?></td>
<td><?php echo e($user->name); ?></td>
<td><?php echo e($user->description); ?></td>
<td><?php echo e($user->gender); ?></td>
<td><?php echo e($user->vehicle); ?></td>
    <td> <img src= "<?php echo e(asset("/image/$user->file")); ?>" style="width:504px;height:228px" /> </td>
    <td><a href = 'employee/edit/<?php echo e($user->id); ?>'>Edit</a></td>
     <td><a href = '/employee/delete/<?php echo e($user->id); ?>'>Delete</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html><?php /**PATH C:\wamp64\www\employeeprjct\resources\views/employee/employeedisplay.blade.php ENDPATH**/ ?>