<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\User;



class UserTablesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        {
        User::create([
            'name'    => 'JohnSmith',
            'email'    => 'john_smith@gmail.com',
            'password'   =>  Hash::make('password'),
            
        ]);
    }
    }
}
