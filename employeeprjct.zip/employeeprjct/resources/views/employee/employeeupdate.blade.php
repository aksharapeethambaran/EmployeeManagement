<!DOCTYPE html>
<html>
<head>
<title>Employee Management</title>
   <h1>Employee Management</h1> 
</head>
<body>
<form action = "{{URL::to('employee/save')}}" method = "post" enctype="multipart/form-data">
    <?php foreach($employee as $row){?>
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
    <input type='hidden' name='editid' value="{{$row->id}}" />
<table>
<tr>
<td>First Name</td>
<td><input type='text' name='name' value="{{$row->name}}" /></td>
</tr>
<tr>
<td>Gender</td>
   
<td><input type="checkbox" name="gender" value="female" <?php echo ($row->gender=='female')?'checked':'' ?>>Female
  <input type="checkbox" name="gender" value="male" <?php echo ($row->gender=='male')?'checked':'' ?>> Male<br></td>
</tr>
<tr>
<td>City Name</td>
<td>
<select name="vehicle" >
   
    <option value="bbsr"<?php if ($row->vehicle == 'bbsr') echo ' selected="selected"'; ?>>Bhubaneswar</option>
    <option value="cuttack"<?php if ($row->vehicle == 'cuttack') echo ' selected="selected"'; ?>>Cuttack</option>
    
</select></td><br><br>
</tr>
    <tr>
<td>Current File</td>
<td><input type="hidden" name='file' value="{{$row->file}}"/></td>
         <td> <img src= "{{ asset("/image/$row->file")}}" style="width:504px;height:228px" /> </td>
</tr>
<tr>
<td>Change File</td>
<td><input type="file" name="image"/></td>
</tr>

    <tr><td>Description</td>
    <td><textarea name="description" rows="9" cols="20"><?php echo $row->description ;?>

</textarea>
        </td></tr>
    <?php } ?>
<tr>
<td colspan = '2'>
<input type = 'submit' value ="Update Employee"/>
</td>
</tr>
</table>
</form>
</body>
</html>