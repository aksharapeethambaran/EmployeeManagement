<!DOCTPE html>
<html>
<head>
<title>View Student Records</title>
    <h1>Employee Management</h1>
    <h3><a href = '{{URL::to('viewemployeeform')}}'>Add Employee</a></h3>
</head>
<body>
<table border = "1">
<tr>
<td>Id</td>
<td>Name</td>
<td>Description</td>
<td>Gender</td>
<td>Vehicle</td>
<td>Image</td>
</tr>
@foreach ($employee as $user)
<tr>
<td>{{ $user->id }}</td>
<td>{{ $user->name }}</td>
<td>{{ $user->description }}</td>
<td>{{ $user->gender }}</td>
<td>{{ $user->vehicle }}</td>
    <td> <img src= "{{ asset("/image/$user->file")}}" style="width:504px;height:228px" /> </td>
    <td><a href = 'employee/edit/{{ $user->id }}'>Edit</a></td>
     <td><a href = '/employee/delete/{{ $user->id }}'>Delete</a></td>
</tr>
@endforeach
</table>
</body>
</html>