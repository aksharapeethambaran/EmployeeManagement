<!DOCTYPE html>
<html>
<head>
<title>Employee Management</title>
   <h1>Employee Management</h1> 
</head>
<body>
<form action = "/create" method = "post" enctype="multipart/form-data">
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<table>
<tr>
<td>First Name</td>
<td><input type='text' name='name' /></td>
</tr>
<tr>
<td>Gender</td>
<td><input type="checkbox" name="gender" value="female"> Female
  <input type="checkbox" name="gender" value="male"> Male<br></td>
</tr>
<tr>
<td>City Name</td>
<td>
<select name="vehicle" >
    <option value="">Select </option>
<option value="bbsr">Bhubaneswar</option>
<option value="cuttack">Cuttack</option>
</select></td><br><br>
</tr>
<tr>
<td>File</td>
<td><input type="file" name='file'/></td>
</tr>

    <tr><td>Description</td>
    <td><textarea name="description" rows="9" cols="20">

</textarea>
        </td></tr>
<tr>
<td colspan = '2'>
<input type = 'submit' value ="Add Employee"/>
</td>
</tr>
</table>
</form>
</body>
</html>